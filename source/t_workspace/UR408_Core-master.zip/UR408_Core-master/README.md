# UR408_Core
A super tiny  8bit customize ISA core with  assembler and an emulator written by MYHDL 



